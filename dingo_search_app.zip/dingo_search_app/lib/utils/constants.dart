class Constants {

  static const APP_NAME = "Open Library App";
  static const BASE_URL = "http://openlibrary.org/";
  static const BASE_URL_COVER = "http://covers.openlibrary.org/";

}