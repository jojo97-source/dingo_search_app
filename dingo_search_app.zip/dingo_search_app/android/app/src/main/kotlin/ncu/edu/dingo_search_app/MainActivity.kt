package ncu.edu.dingo_search_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
